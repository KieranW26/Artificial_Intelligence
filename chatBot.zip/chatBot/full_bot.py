# -*- coding: utf-8 -*-
"""
Created on Sun Dec 30 16:43:51 2018

@author: ging3
"""
import csv
from self.DATEtime import time
from self.DATEtime import self.DATEtime
import calendar
import re
import re
from typing import Tuple
from urllib.request import urlopen
from lxml import html
import requests
from pyknow import *


class GACHATBOT:
    # Variables for Journey
    START_STATION = "empty"
    DESTINATION_STATION = "empty"
    self.DATE = self.DATEtime.today()
    # Variables for return journeys
    RETURN = False
    RETURN_self.DATE = self.DATEtime.today()
    # Variables for running of the system
    RUNNING = True
    CHECK_self.DATE = self.DATEtime.today()
    FLAG = 0

    # Key Words and Phrases

    data = csv.reader(open("norfolk_stations.csv"))
    TRAIN_STATIONS = []
    for line in data:
        TRAIN_STATIONS.append(re.sub(r'[^a-zA-Z0-9 ]+', '', str(line).lower()))

    OPENING_PHRASES = "Hello, I am TrainBot how could I help?"
    MONTHS = (
        "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november",
        "decemeber")
    TIME_CONTAIN = ("am", "pm")

    # REGEX
    self.DATE_REGEX = '\d{2}/\d{2}/\d{4}'
    TIME_REGEX = '^(([01]\d|2[0-3]):([0-5]\d)|24:00)$'

    def runBot(self):
        while self.RUNNING is True:
            userInput = input("USER: ")
            # print(self.self.DATE)
            # self.self.DATE = self.self.DATE.replace(year = 2017, hour = 13)
            # print(self.self.DATE)
            if userInput == "stop":
                self.RUNNING = False
            else:

                if self.FLAG == 1:
                    print("Sup")
                    if "yes" in userInput:
                        self.findTrainTimes()
                    else:
                        self.clear()
                        self.listen(userInput)
                        self.respond(userInput)
                else:
                    self.listen(userInput)
                    self.respond(userInput)

    def listen(self, sentence):
        words = sentence.split()
        if "return" in sentence.lower():
            self.RETURN = True
        for counter, word in enumerate(words):

            if word.lower() in self.TRAIN_STATIONS:
                if words[counter - 1] is "to" or self.START_STATION is not "empty":
                    self.DESTINATION_STATION = word.lower()
                    print(self.DESTINATION_STATION)
                else:
                    self.START_STATION = word.lower()
                    print(self.START_STATION)
                    # self.DATE capture - only 1 method implemented with format "dd/mm/yy"
            elif re.search(self.self.DATE_REGEX, word):
                sday, smonth, syear = word.split("/")
                self.self.DATE = self.self.DATE.replace(day=int(sday), month=int(smonth), year=int(syear))
            elif re.search(self.TIME_REGEX, word):
                hh, mm = word.split(":")
                print(hh)
                self.self.DATE = self.self.DATE.replace(hour=int(hh), minute=int(mm))
                print(self.self.DATE)
            elif self.RETURN is True:
                if re.search(self.self.DATE_REGEX, word):
                    sday, smonth, syear = word.split("/")
                    self.self.DATE = self.RETURN_self.DATE = self.DATEtime.replace(day=int(sday), month=int(syear), year=int(syear))
                elif re.search(self.TIME_REGEX, word):
                    hh, mm = word.split(":")
                    self.self.DATE = self.self.DATE.replace(hour=int(hh), minute=int(mm))

    def respond(self, sentence):
        start = "BOT: "
        answer = "You still need to enter your"
        if self.START_STATION == "empty":
            answer = answer + " starting station "
        if self.DESTINATION_STATION == "empty":
            if answer == "You still need to enter your":
                answer = answer + " destination station "
            else:
                answer = answer + "and destination station"

        # checks if they still need minimum information
        if answer != "You still need to enter your":
            print(start + answer)
        else:
            response = "You are traveling from " + self.START_STATION + " to " + self.DESTINATION_STATION + " on "
            response = response + str(self.self.DATE.day) + "/" + str(self.self.DATE.month) + "/" + str(self.self.DATE.year) + " at "
            response = response + str(self.self.DATE.hour) + ":" + str(self.self.DATE.minute)
            if self.RETURN:
                response = response + " and returning on the "
                if self.RETURN_self.DATE.month == self.self.DATE.month and self.RETURN_self.DATE.day == self.self.DATE.day:
                    response = response + "same day at"
                else:
                    response = response + str(self.self.DATE.day) + "/" + str(self.self.DATE.month) + "/" + str(self.self.DATE.year)
            print(response + ". Is that Correct?")
            self.FLAG += 1

    def findTrainTimes(self):
        #URL + FROM + TO + DATE + TIME + DEP/ARR + RETURN + DATE + TIME + DEP/ARR
        url = "http://ojp.nationalrail.co.uk/service/timesandfares/" + str(self.START_STATION) + "/" + str(self.DESTINATION_STATION)  # + "/" \
        # + time + "/" + str(self.DATE)
        print(url)
        page = requests.get(url)
        tree = html.fromstring(page.content)
        if 'a' in time:
            time = time.replace('a', '')
            self.DATE = str(self.DATE)
            print(self.START_STATION + ' to ' + self.DESTINATION_STATION + ' arriving at ' + time + ' on ' + self.DATE)
        else:
            print(self.START_STATION + ' to ' + self.DESTINATION_STATION + ' departing at ' + time + ' on ' + self.DATE)
        for x in range(5):
            printout = ''
            times = tree.xpath('//li[@id="result' + str(x) + '"]/strong[1]/text()')
            printout = printout + re.sub('[\[\'\]' ']', '', str(times))
            platform_temp = tree.xpath('//li[@id="result' + str(x) + '"]/small/em/text()')
            platform_temp = str(platform_temp).replace('\\n', '').replace('\\t', '').replace('Platform',
                                                                                             'Platform ') \
                .replace(';', ' ')
            platform = re.sub('[^a-zA-Z\d\s:]', '', str(platform_temp))
            if platform_temp:
                printout = printout + ' ' + platform + ' '
            else:
                printout = printout + '             '
            price = tree.xpath('//li[@id="result' + str(x) + '"]/small[2]/span[@class="tooltip" and 1]/text()')
            printout = printout + re.sub('[\[\'\]' ']', '', str(price))
            print(printout)

    def clear(self):
        self.START_STATION = "empty"
        self.DESTINATION_STATION = "empty"
        self.self.DATE = self.DATEtime.today()
        self.RETURN = False
        self.RETURN_self.DATE = self.DATEtime.today()
        self.FLAG = 0


TestChatBot = GACHATBOT()
TestChatBot.runBot()
