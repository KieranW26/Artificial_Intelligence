import csv
import datetime
import re

import requests
from lxml import html


def predictionText(stationName):
    csv_file = csv.reader(open('norfolk_station_codes_with_names.csv', "rt"), delimiter=",")
    score = 0
    bestmatchs = ('','','')
    if len(stationName) == 3:
        for row in csv_file:
            for i in stationName:
                score = stationName[i] - row[i]
                print(score)



class CheapestTrainJourney:

    from_station_name = "KLN"
    to_station_name = "London"
    from_station = ''
    to_station = ''
    date = ""
    time = ""
    deparr = ""
    ret_date = "12012019"
    ret_time = ""
    ret_deparr = ""

    csv_file = csv.reader(open('norfolk_station_codes_with_names.csv', "rt"), delimiter=",")

    for row in csv_file:
        if from_station_name in row[0] or from_station_name in row[1]:
            from_station_name = row[0]
            from_station = row[1]
        elif to_station_name in row[0] or to_station_name in row[1]:
            to_station_name = row[0]
            to_station = row[1]
    if from_station == '' and to_station == '':
        print("Sorry, neither station " + from_station_name + " or " + to_station_name + " could be found.")
    if from_station == '':
        print("Sorry, no station matching " + from_station_name + " can be found.")
    elif to_station == '':
        print("Sorry, no station matching " + to_station_name + " can be found.")
    else:
        url = "http://ojp.nationalrail.co.uk/service/timesandfares/" + from_station + "/" + to_station
        if date == "":
            date = "today"
        url = url + "/" + date
        if time == "":
            time = str(datetime.datetime.now().time())
            time = time[0:2] + time[3:5]
        url = url + "/" + time
        if deparr == "":
            deparr = "dep"
        url = url + "/" + deparr
        if ret_date != "":
            url = url + "/" + ret_date
            if ret_time == "":
                url = url + "/" + "0900/first"
            else:
                url = url + "/" + ret_time
                if ret_deparr == "":
                    url = url + "/dep"
                else:
                    url = url + "/" + ret_deparr
            page = requests.get(url)
            tree = html.fromstring(page.content)
            price = tree.xpath('//*[@id="singleFaresPane"]/strong/text()')
        else:

            page = requests.get(url)
            tree = html.fromstring(page.content)
            price = tree.xpath('//*[@id="fare-switcher"]/div/a/strong/text()')

        price = re.sub(',.*$|[^£\d\.]', '', str(price))

        f_time_dep = re.sub('[^£\d\.:]', '', str(tree.xpath('//*[@id="oft"]/tbody/tr[1]/td[1]/text()')))
        f_time_arr = re.sub('[^£\d\.:]', '', str(tree.xpath('//*[@id="oft"]/tbody/tr[1]/td[4]/text()')))
        f_price = re.sub('[^£\d\.]', '', str(tree.xpath('//*[@id="oft"]/tbody/tr[1]/td[9]/div/label/text()')))
        service = re.sub('[^A-Za-z ]', '', str(tree.xpath('//*[@id="oft"]/tbody/tr[1]/td[8]/div/div/a/text()')))
        ret_dep_time = re.sub('[^£\d\.:]', '', str(tree.xpath('//*[@id="ift"]/tbody/tr[1]/td[1]/text()')))
        ret_arr_time = re.sub('[^£\d\.:]', '', str(tree.xpath('//*[@id="ift"]/tbody/tr[1]/td[4]/text()')))
        ret_f_price = re.sub('[^£\d\.:]', '', str(tree.xpath('//*[@id="ift"]/tbody/tr[1]/td[9]/div[2]/label/text()')))
        if ret_date == "":
            output = "The train closest to your chosen time leaves " + from_station_name + " at " \
                     + f_time_dep + " and arrives at " + to_station_name + " at " + f_time_arr + " costing " + f_price

            if price == f_price:
                output = output + ". This is the cheapest fare around those times." \
                         " This service is currently running: " + service
            else:
                output = output + "\n" + "Cheapest price found from " + from_station_name + " to " + to_station_name \
                         + " for " + price + ". This service is currently running: " + service

        else:
            ret_f_price = re.sub('[^\d]', '', ret_f_price)
            f_price = re.sub('[^\d]', '', f_price)
            total_price = float(f_price) + float(ret_f_price)
            total_price = total_price / 100
            total_price = str("£" + "%.2f" % total_price)
            output = "The train closest to your chosen time leaves " + from_station_name + " at " \
                     + f_time_dep + " and arrives at " + to_station_name + " at " + f_time_arr + ".\nYour return " \
                     "journey will leave " + to_station_name + " at " + ret_dep_time + " and arrives at " \
                     + from_station_name + " at " + ret_arr_time + ".\nThis journey will cost " \
                     + total_price
            if total_price != price:
                output = output + "\nCheapest return journey from " + from_station_name + " to " + to_station_name \
                         + " for " + price

                #TODO: ADD DATES
                #TODO: ADD PREDICTION TEXT
                #TODO: ADD 'NEXT TRAIN'
                #TODO: ADD 'FIRST/LAST TRAIN'
                #TODO: COMMENTS
        print(output)
        print(url)

        predictionText('bcl')



