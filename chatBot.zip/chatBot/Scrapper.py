import datetime


def findTrainTimes(self):
    # URL + FROM + TO + DATE + TIME + DEP/ARR + RETURN + DATE + TIME + DEP/ARR
    from_station = "Norwich"
    to_station = "London"
    date = "04012019"
    time = "1300"
    deparr = "dep"
    ret_date = "06012019"
    ret_time = "1300"
    ret_deparr = "arr"

    url = "http://ojp.nationalrail.co.uk/service/timesandfares/" + from_station + "/" + to_station
    if date == "":
        date = "today"
    url = url + "/" + date
    if time == "":
        time = str(datetime.datetime.now().time())
        time = time[0:2] + time [3:5]
        print(time)
    url = url + "/" + time
    if deparr == "":
        deparr = "dep"
    url = url + "/" + deparr







          str(self.START_STATION) + "/" + str(
        self.DESTINATION_STATION)  # + "/" \
    # + time + "/" + str(self.DATE)
    print(url)
    page = requests.get(url)
    tree = html.fromstring(page.content)
    if 'a' in time:
        time = time.replace('a', '')
        self.DATE = str(self.DATE)
        print(self.START_STATION + ' to ' + self.DESTINATION_STATION + ' arriving at ' + time + ' on ' + self.DATE)
    else:
        print(self.START_STATION + ' to ' + self.DESTINATION_STATION + ' departing at ' + time + ' on ' + self.DATE)
    for x in range(5):
        printout = ''
        times = tree.xpath('//li[@id="result' + str(x) + '"]/strong[1]/text()')
        printout = printout + re.sub('[\[\'\]' ']', '', str(times))
        platform_temp = tree.xpath('//li[@id="result' + str(x) + '"]/small/em/text()')
        platform_temp = str(platform_temp).replace('\\n', '').replace('\\t', '').replace('Platform',
                                                                                         'Platform ') \
            .replace(';', ' ')
        platform = re.sub('[^a-zA-Z\d\s:]', '', str(platform_temp))
        if platform_temp:
            printout = printout + ' ' + platform + ' '
        else:
            printout = printout + '             '
        price = tree.xpath('//li[@id="result' + str(x) + '"]/small[2]/span[@class="tooltip" and 1]/text()')
        printout = printout + re.sub('[\[\'\]' ']', '', str(price))
        print(printout)